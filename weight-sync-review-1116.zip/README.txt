Weight synchronization review regressions

The logs and JUnit results record actual CPU runs, including Gloo collectives, HTTP/TCP sockets and Ray/Serve restarts.
Paths, hostnames and node addresses are normalized for publication. Original logs are retained locally.
Run the listed test files with: python -m pytest -q --tb=short --junitxml=results.xml <test files>
results.json identifies the contribution commits. test-provenance.json records source matching and later test-fixture changes.
pr2-final and pr2-ray are separate test groups. pr2-ranks rechecks distributed teardown. Counts across PRs overlap.
These are CPU review regressions; existing GPU and performance evidence remains in weight-sync-evidence.zip.
